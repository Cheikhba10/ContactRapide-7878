package com.contactrapide.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

public class ProfileActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(30, 35, 30, 30);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setBackgroundColor(Color.rgb(248, 249, 252));

        TextView logo = new TextView(this);
        logo.setText("🇸🇳");
        logo.setTextSize(50);
        logo.setGravity(Gravity.CENTER);
        page.addView(logo);

        TextView nom = new TextView(this);
        nom.setText("24/24 AGENCY");
        nom.setTextSize(30);
        nom.setTextColor(Color.rgb(0, 90, 55));
        nom.setGravity(Gravity.CENTER);
        nom.setTypeface(null, 1);
        page.addView(nom);

        TextView description = new TextView(this);
        description.setText(
                "La tranquillité d'esprit n'a pas de prix\n\n" +
                "Agence de services et d'assistance disponible 24h/24."
        );
        description.setTextSize(18);
        description.setGravity(Gravity.CENTER);
        page.addView(description);

        TextView telephone = new TextView(this);
        telephone.setText("\n📞 76 130 13 30");
        telephone.setTextSize(22);
        telephone.setGravity(Gravity.CENTER);
        page.addView(telephone);

        TextView services = new TextView(this);
        services.setText(
                "\n🛠 Nos services\n\n" +
                "👶 Nanny / Garde d'enfants\n" +
                "🧹 Ménage / Nettoyage\n" +
                "🍽️ Cuisine\n" +
                "🚗 Chauffeur\n" +
                "🌳 Jardinage"
        );
        services.setTextSize(18);
        services.setGravity(Gravity.CENTER);
        page.addView(services);

        Button whatsapp = new Button(this);
        whatsapp.setText("💬 CONTACTER SUR WHATSAPP");
        whatsapp.setTextColor(Color.WHITE);
        whatsapp.setBackgroundColor(Color.rgb(0, 105, 70));
        page.addView(whatsapp);

        whatsapp.setOnClickListener(v -> {
            Intent intent = new Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://wa.me/221761301330")
            );
            startActivity(intent);
        });

        setContentView(page);
    }
}
